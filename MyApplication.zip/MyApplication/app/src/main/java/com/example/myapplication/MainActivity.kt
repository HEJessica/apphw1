package com.example.myapplication

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.MessageQueue
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

@Suppress("DEPRECATTION")
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val nameEditText1 = findViewById<EditText>(R.id.nameEditText1)
        val nameEditText2 = findViewById<EditText>(R.id.nameEditText2)

        val bundle = Bundle()
        bundle.putString("key1", nameEditText1.text.toString())
        bundle.putString("key2", nameEditText2.text.toString())


        val button = findViewById<Button>(R.id.button)
        button.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            intent.putExtras(bundle)
            startActivityForResult(intent, 1)
        }
    }

   override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
      super.onActivityResult(requestCode, resultCode, data)

       data?.extras?.let{
               if (requestCode==1 && requestCode== Activity.RESULT_OK)
               {
                 findViewById<TextView>(R.id.textView2).text=
                    "name: ${it.getString("key1")}\n\n" +
                    "sex: ${it.getString("key2")}\n\n" +
                    "size: ${it.getString("key3")}\n\n" +
                    "color: ${it.getString("key4")}\n\n"
               }
        }
    }
}

