package com.example.myapplication

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val nameEditText3 = findViewById<EditText>(R.id.nameEditText3)
        val nameEditText4 = findViewById<EditText>(R.id.nameEditText4)

       intent ?.extras?.let {
           val value1 = it.getString("key1")
           val value2 = it.getString("key2")

           val bundle = Bundle()
           bundle.putString("key3", nameEditText3.text.toString())
           bundle.putString("key4", nameEditText4.text.toString())

           val button1 = findViewById<Button>(R.id.button2)
           button1.setOnClickListener {
               val intent = Intent().putExtras(bundle)
               setResult(Activity.RESULT_OK, intent.putExtras(bundle))
               finish()
           }
       }
    }
}